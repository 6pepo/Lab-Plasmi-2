# Compass_reader

Python class that reads binary output of Caen Compass, providing an object containing waveforms and Qlong, Qshort.

Two functions allows to plot the single waveforms and the spectrum (Qlong)


Requires Numpy and Matplotlib


